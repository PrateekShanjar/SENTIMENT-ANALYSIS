<img width="1912" height="954" alt="image" src="https://github.com/user-attachments/assets/b33606aa-697f-4973-a266-cdea80bfc593" />




<img width="1908" height="954" alt="image" src="https://github.com/user-attachments/assets/4398a91e-acba-4383-87fb-672481d529e1" />



<img width="1905" height="948" alt="image" src="https://github.com/user-attachments/assets/007bbf9d-a659-4bf5-8270-9445ad551aef" />



<img width="1906" height="991" alt="image" src="https://github.com/user-attachments/assets/c1b1cde1-3ea9-4ddc-b5e5-9ff8bf3525e9" />



<img width="1919" height="1001" alt="image" src="https://github.com/user-attachments/assets/7ad16092-9d4a-4fa3-a1a0-b0f3bec4b2f9" />



<img width="1919" height="973" alt="image" src="https://github.com/user-attachments/assets/df5b8e80-f78a-41d2-9f17-becfab024e42" />



<img width="1918" height="966" alt="image" src="https://github.com/user-attachments/assets/0bfcbdf2-e1ea-4423-bd70-32191d81af41" />
